var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/[id]/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_c59baf65.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f4203179._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_[id]_route_actions_521bfe4c.js")
R.m(48001)
module.exports=R.m(48001).exports
