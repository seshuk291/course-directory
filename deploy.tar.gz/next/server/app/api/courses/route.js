var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/courses/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_7373c198.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f4203179._.js")
R.c("server/chunks/_next-internal_server_app_api_courses_route_actions_b7ed85a6.js")
R.m(15037)
module.exports=R.m(15037).exports
