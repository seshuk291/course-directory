var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/folders/[folderId]/route.js")
R.c("server/chunks/[root-of-the-server]__ba9d88d5._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/ce889_server_app_api_directories_[id]_folders_[folderId]_route_actions_0b141d1f.js")
R.m(23425)
module.exports=R.m(23425).exports
