var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/progress/route.js")
R.c("server/chunks/[root-of-the-server]__01ad40d4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_directories_[id]_progress_route_actions_1493af48.js")
R.m(85177)
module.exports=R.m(85177).exports
