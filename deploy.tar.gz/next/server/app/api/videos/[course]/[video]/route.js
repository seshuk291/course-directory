var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/videos/[course]/[video]/route.js")
R.c("server/chunks/[root-of-the-server]__6259d46e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_videos_[course]_[video]_route_actions_bcdb1aef.js")
R.m(44165)
module.exports=R.m(44165).exports
