module.exports=[93695,(e,r,t)=>{r.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},18622,(e,r,t)=>{r.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,r,t)=>{r.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},14747,(e,r,t)=>{r.exports=e.x("path",()=>require("path"))},88917,(e,r,t)=>{r.exports=e.x("sqlite3",()=>require("sqlite3"))},84168,e=>{"use strict";var r=e.i(88917),t=e.i(14747);let a=t.default.join(process.cwd(),"course-directories.db");async function i(){return new Promise((e,t)=>{let i=new r.default.Database(a,r=>{r?t(r):(console.log("Running database migrations..."),i.serialize(()=>{i.run(`
          CREATE TABLE IF NOT EXISTS migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),i.get("SELECT name FROM migrations WHERE name = 'add_category_support'",(r,a)=>{var n,d,E,s,l,T;r?t(r):a?(console.log("Migration already applied: add_category_support"),n=i,d=()=>{o(i,e,t)},E=t,n.get("SELECT name FROM sqlite_master WHERE type='table' AND name='chapters'",(e,r)=>{e?E(e):r?(console.log("Chapters table already exists"),d()):(console.log("Creating missing chapters table..."),n.run(`
          CREATE TABLE IF NOT EXISTS chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            folder_id INTEGER,
            name TEXT NOT NULL,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            original_path TEXT,
            type TEXT DEFAULT 'html',
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
          )
        `,e=>{e?(console.error("Error creating chapters table:",e),E(e)):(console.log("Chapters table created successfully"),d())}))})):(console.log("Running migration: add_category_support"),s=i,l=()=>{o(i,e,t)},T=t,s.run(`
    CREATE TABLE IF NOT EXISTS selected_directories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      original_path TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),s.run(`
    CREATE TABLE IF NOT EXISTS course_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      color TEXT DEFAULT '#3b82f6',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),s.all("PRAGMA table_info(selected_directories)",(e,r)=>{e?T(e):(r.some(e=>"category_id"===e.name)||s.run(`
          ALTER TABLE selected_directories 
          ADD COLUMN category_id INTEGER REFERENCES course_categories(id)
        `),s.run(`
        CREATE TABLE IF NOT EXISTS folder_hierarchy (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          parent_id INTEGER,
          folder_name TEXT NOT NULL,
          display_name TEXT,
          folder_path TEXT NOT NULL,
          level INTEGER DEFAULT 0,
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
        )
      `),s.run(`
        CREATE TABLE IF NOT EXISTS chapters (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          folder_id INTEGER,
          name TEXT NOT NULL,
          filename TEXT NOT NULL,
          path TEXT NOT NULL,
          original_path TEXT,
          type TEXT DEFAULT 'html',
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
        )
      `),s.run("INSERT INTO migrations (name) VALUES ('add_category_support')",e=>{e?T(e):(console.log("Migration completed: add_category_support"),l())}))}))})}))})})}function o(e,r,t){e.get("SELECT name FROM migrations WHERE name = 'add_progress_tracking'",(a,i)=>{a?t(a):i?(console.log("Migration already applied: add_progress_tracking"),e.close(e=>{e?t(e):r()})):(console.log("Running migration: add_progress_tracking"),e.run(`
          CREATE TABLE IF NOT EXISTS chapter_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            chapter_path TEXT NOT NULL,
            completed BOOLEAN DEFAULT FALSE,
            completed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            UNIQUE(directory_id, chapter_path)
          )
        `,a=>{if(a){console.error("Error creating chapter_progress table:",a),t(a);return}e.run("INSERT INTO migrations (name) VALUES ('add_progress_tracking')",a=>{a?t(a):(console.log("Migration completed: add_progress_tracking"),e.close(e=>{e?t(e):r()}))})}))})}let n=t.default.join(process.cwd(),"course-directories.db");function d(){return new Promise(async(e,t)=>{try{await i()}catch(e){console.error("Migration failed:",e)}let a=new r.default.Database(n,r=>{r?t(r):a.serialize(()=>{a.run(`
          CREATE TABLE IF NOT EXISTS course_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            color TEXT DEFAULT '#3b82f6',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS selected_directories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            category_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES course_categories (id) ON DELETE SET NULL
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS custom_names (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            file_path TEXT NOT NULL,
            original_name TEXT NOT NULL,
            custom_name TEXT NOT NULL,
            is_directory BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS folder_hierarchy (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            parent_id INTEGER,
            folder_name TEXT NOT NULL,
            display_name TEXT,
            folder_path TEXT NOT NULL,
            level INTEGER DEFAULT 0,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
          )
        `),e(a)})})})}class E{db=null;async init(){this.db=await d()}async addDirectory(e,r,t){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT OR REPLACE INTO selected_directories (original_path, display_name, category_id, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      `);o.run([e,r,t||null],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getSelectedDirectories(){return new Promise((e,r)=>{this.db?this.db.all("SELECT * FROM selected_directories ORDER BY display_name",(t,a)=>{t?r(t):e(a)}):r(Error("Database not initialized"))})}async removeDirectory(e){return new Promise((r,t)=>{this.db?this.db.run("DELETE FROM selected_directories WHERE id = ?",[e],e=>{e?t(e):r()}):t(Error("Database not initialized"))})}async updateDirectory(e,r,t){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        UPDATE selected_directories 
        SET display_name = ?, category_id = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);o.run([r,t||null,e],e=>{e?i(e):a()}),o.finalize()})}async setCustomName(e,r,t,a,i=!1){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let d=this.db.prepare(`
        INSERT OR REPLACE INTO custom_names 
        (directory_id, file_path, original_name, custom_name, is_directory, updated_at) 
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `);d.run([e,r,t,a,i],e=>{e?n(e):o()}),d.finalize()})}async getCustomNames(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM custom_names WHERE directory_id = ?",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async close(){return new Promise((e,r)=>{this.db?this.db.close(t=>{t?r(t):e()}):e()})}async createCategory(e,r,t="#3b82f6"){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT INTO course_categories (name, description, color) 
        VALUES (?, ?, ?)
      `);o.run([e,r||null,t],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getCategories(){return new Promise((e,r)=>{this.db?this.db.all("SELECT * FROM course_categories ORDER BY name",(t,a)=>{t?r(t):e(a)}):r(Error("Database not initialized"))})}async updateCategory(e,r,t,a){return new Promise((i,o)=>{if(!this.db)return void o(Error("Database not initialized"));let n=this.db.prepare(`
        UPDATE course_categories 
        SET name = ?, description = ?, color = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);n.run([r,t||null,a||"#3b82f6",e],e=>{e?o(e):i()}),n.finalize()})}async deleteCategory(e){return new Promise((r,t)=>{this.db?this.db.run("DELETE FROM course_categories WHERE id = ?",[e],e=>{e?t(e):r()}):t(Error("Database not initialized"))})}async createFolderHierarchy(e,r,t,a,i){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let d=0;if(a)this.db.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(E,s)=>{if(E)return void n(E);s&&(d=s.level+1);let l=this.db.prepare(`
              INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
              VALUES (?, ?, ?, ?, ?, ?)
            `);l.run([e,a||null,r,i||null,t,d],function(e){e?n(e):o(this.lastID)}),l.finalize()});else{let a=this.db.prepare(`
          INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
          VALUES (?, ?, ?, ?, ?, ?)
        `);a.run([e,null,r,i||null,t,d],function(e){e?n(e):o(this.lastID)}),a.finalize()}})}async getFolderHierarchy(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async getDirectoriesWithCategories(){return new Promise((e,r)=>{if(!this.db)return void r(Error("Database not initialized"));let t=`
        SELECT d.*, c.name as category_name, c.description as category_description, c.color as category_color
        FROM selected_directories d
        LEFT JOIN course_categories c ON d.category_id = c.id
        ORDER BY c.name, d.display_name
      `;this.db.all(t,(t,a)=>{t?r(t):e(a.map(e=>({id:e.id,original_path:e.original_path,display_name:e.display_name,category_id:e.category_id,created_at:e.created_at,updated_at:e.updated_at,category:e.category_name?{id:e.category_id,name:e.category_name,description:e.category_description,color:e.category_color,created_at:"",updated_at:""}:void 0})))})})}async markChapterCompleted(e,r){return new Promise((t,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `);i.run([e,r,!0],e=>{e?a(e):t()}),i.finalize()})}async markChapterIncomplete(e,r){return new Promise((t,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, NULL, CURRENT_TIMESTAMP)
      `);i.run([e,r,!1],e=>{e?a(e):t()}),i.finalize()})}async getChapterProgress(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM chapter_progress WHERE directory_id = ?",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async getCourseProgress(e){return new Promise((r,t)=>{this.db?this.db.get("SELECT COUNT(*) as total FROM chapters WHERE directory_id = ?",[e],(a,i)=>{if(a)return void t(a);let o=i?.total||0;this.db?this.db.get("SELECT COUNT(*) as completed FROM chapter_progress WHERE directory_id = ? AND completed = ?",[e,!0],(e,a)=>{if(e)t(e);else{let e=a?.completed||0,t=o>0?Math.round(e/o*100):0;r({total:o,completed:e,percentage:t})}}):t(Error("Database not initialized"))}):t(Error("Database not initialized"))})}}async function s(e){let r=await d();return new Promise((t,a)=>{r.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,r)=>{e?a(e):t((r||[]).map(e=>({...e,name:e.folder_name,displayName:e.display_name,path:e.folder_path,parentId:e.parent_id,children:[],chapters:[],sortOrder:e.sort_order})))})})}async function l(e,r,t,a){let i=await d();return new Promise((o,n)=>{let d=0;a?i.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(E,s)=>{E?n(E):(d=(s?.level||0)+1,i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
             VALUES (?, ?, ?, ?, ?, ?)`,[e,a,r,t,r,d],function(e){e?n(e):o(this.lastID)}))}):i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
         VALUES (?, ?, ?, ?, ?, ?)`,[e,null,r,t,r,0],function(e){e?n(e):o(this.lastID)})})}e.s(["DirectoryManager",()=>E,"createFolder",()=>l,"getDirectoryFolders",()=>s,"initDatabase",()=>d],84168)},19071,e=>{"use strict";var r=e.i(47909),t=e.i(74017),a=e.i(96250),i=e.i(59756),o=e.i(61916),n=e.i(14444),d=e.i(37092),E=e.i(69741),s=e.i(16795),l=e.i(87718),T=e.i(95169),c=e.i(47587),p=e.i(66012),R=e.i(70101),u=e.i(26937),_=e.i(10372),N=e.i(93695);e.i(52474);var A=e.i(220),h=e.i(89171),I=e.i(84168);async function m(e,{params:r}){try{let{id:t,folderId:a}=await r,i=parseInt(t),o=parseInt(a);if(isNaN(i)||isNaN(o))return h.NextResponse.json({error:"Invalid directory or folder ID"},{status:400});let{direction:n}=await e.json();if(!["up","down"].includes(n))return h.NextResponse.json({error:"Invalid direction"},{status:400});let d=await (0,I.initDatabase)(),E=await new Promise((e,r)=>{d.get("SELECT * FROM folder_hierarchy WHERE id = ? AND directory_id = ?",[o,i],(t,a)=>{t?r(t):e(a)})});if(!E)return d.close(),h.NextResponse.json({error:"Folder not found"},{status:404});let s="up"===n?"<":">",l="up"===n?"DESC":"ASC",T=await new Promise((e,r)=>{d.get(`SELECT * FROM folder_hierarchy 
         WHERE directory_id = ? AND parent_id ${E.parent_id?"= ?":"IS NULL"} 
         AND sort_order ${s} ? 
         ORDER BY sort_order ${l} 
         LIMIT 1`,E.parent_id?[i,E.parent_id,E.sort_order]:[i,E.sort_order],(t,a)=>{t?r(t):e(a)})});return T&&await new Promise((e,r)=>{d.run("UPDATE folder_hierarchy SET sort_order = ? WHERE id = ?",[T.sort_order,o],t=>{t?r(t):d.run("UPDATE folder_hierarchy SET sort_order = ? WHERE id = ?",[E.sort_order,T.id],t=>{t?r(t):e()})})}),d.close(),h.NextResponse.json({message:"Folder reordered successfully"})}catch(e){return console.error("Error reordering folder:",e),h.NextResponse.json({error:"Failed to reorder folder"},{status:500})}}e.s(["PUT",()=>m],53355);var y=e.i(53355);let g=new r.AppRouteRouteModule({definition:{kind:t.RouteKind.APP_ROUTE,page:"/api/directories/[id]/folders/[folderId]/reorder/route",pathname:"/api/directories/[id]/folders/[folderId]/reorder",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/directories/[id]/folders/[folderId]/reorder/route.ts",nextConfigOutput:"standalone",userland:y}),{workAsyncStorage:L,workUnitAsyncStorage:C,serverHooks:f}=g;function U(){return(0,a.patchFetch)({workAsyncStorage:L,workUnitAsyncStorage:C})}async function M(e,r,a){g.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let h="/api/directories/[id]/folders/[folderId]/reorder/route";h=h.replace(/\/index$/,"")||"/";let I=await g.prepare(e,r,{srcPage:h,multiZoneDraftMode:!1});if(!I)return r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:m,params:y,nextConfig:L,parsedUrl:C,isDraftMode:f,prerenderManifest:U,routerServerContext:M,isOnDemandRevalidate:D,revalidateOnlyGenerated:S,resolvedPathname:O,clientReferenceManifest:b,serverActionsManifest:F}=I,P=(0,E.normalizeAppPath)(h),v=!!(U.dynamicRoutes[P]||U.routes[O]),w=async()=>((null==M?void 0:M.render404)?await M.render404(e,r,C,!1):r.end("This page could not be found"),null);if(v&&!f){let e=!!U.routes[O],r=U.dynamicRoutes[P];if(r&&!1===r.fallback&&!e){if(L.experimental.adapterPath)return await w();throw new N.NoFallbackError}}let x=null;!v||g.isDev||f||(x="/index"===(x=O)?"/":x);let X=!0===g.isDev||!v,G=v&&!X;F&&b&&(0,n.setReferenceManifestsSingleton)({page:h,clientReferenceManifest:b,serverActionsManifest:F,serverModuleMap:(0,d.createServerModuleMap)({serverActionsManifest:F})});let Y=e.method||"GET",H=(0,o.getTracer)(),z=H.getActiveScopeSpan(),K={params:y,prerenderManifest:U,renderOpts:{experimental:{authInterrupts:!!L.experimental.authInterrupts},cacheComponents:!!L.cacheComponents,supportsDynamicResponse:X,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:L.cacheLife,waitUntil:a.waitUntil,onClose:e=>{r.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(r,t,a)=>g.onRequestError(e,r,a,M)},sharedContext:{buildId:m}},k=new s.NodeNextRequest(e),j=new s.NodeNextResponse(r),q=l.NextRequestAdapter.fromNodeNextRequest(k,(0,l.signalFromNodeResponse)(r));try{let n=async e=>g.handle(q,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let t=H.getRootSpanAttributes();if(!t)return;if(t.get("next.span_type")!==T.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${t.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=t.get("next.route");if(a){let r=`${Y} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":r}),e.updateName(r)}else e.updateName(`${Y} ${h}`)}),d=!!(0,i.getRequestMeta)(e,"minimalMode"),E=async i=>{var o,E;let s=async({previousCacheEntry:t})=>{try{if(!d&&D&&S&&!t)return r.statusCode=404,r.setHeader("x-nextjs-cache","REVALIDATED"),r.end("This page could not be found"),null;let o=await n(i);e.fetchMetrics=K.renderOpts.fetchMetrics;let E=K.renderOpts.pendingWaitUntil;E&&a.waitUntil&&(a.waitUntil(E),E=void 0);let s=K.renderOpts.collectedTags;if(!v)return await (0,p.sendResponse)(k,j,o,K.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),r=(0,R.toNodeOutgoingHttpHeaders)(o.headers);s&&(r[_.NEXT_CACHE_TAGS_HEADER]=s),!r["content-type"]&&e.type&&(r["content-type"]=e.type);let t=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=_.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=_.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:r},cacheControl:{revalidate:t,expire:a}}}}catch(r){throw(null==t?void 0:t.isStale)&&await g.onRequestError(e,r,{routerKind:"App Router",routePath:h,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:D})},M),r}},l=await g.handleResponse({req:e,nextConfig:L,cacheKey:x,routeKind:t.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:U,isRoutePPREnabled:!1,isOnDemandRevalidate:D,revalidateOnlyGenerated:S,responseGenerator:s,waitUntil:a.waitUntil,isMinimalMode:d});if(!v)return null;if((null==l||null==(o=l.value)?void 0:o.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(E=l.value)?void 0:E.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});d||r.setHeader("x-nextjs-cache",D?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),f&&r.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let T=(0,R.fromNodeOutgoingHttpHeaders)(l.value.headers);return d&&v||T.delete(_.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||r.getHeader("Cache-Control")||T.get("Cache-Control")||T.set("Cache-Control",(0,u.getCacheControlHeader)(l.cacheControl)),await (0,p.sendResponse)(k,j,new Response(l.value.body,{headers:T,status:l.value.status||200})),null};z?await E(z):await H.withPropagatedContext(e.headers,()=>H.trace(T.BaseServerSpan.handleRequest,{spanName:`${Y} ${h}`,kind:o.SpanKind.SERVER,attributes:{"http.method":Y,"http.target":e.url}},E))}catch(r){if(r instanceof N.NoFallbackError||await g.onRequestError(e,r,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:D})}),v)throw r;return await (0,p.sendResponse)(k,j,new Response(null,{status:500})),null}}e.s(["handler",()=>M,"patchFetch",()=>U,"routeModule",()=>g,"serverHooks",()=>f,"workAsyncStorage",()=>L,"workUnitAsyncStorage",()=>C],19071)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1c5d49f6._.js.map