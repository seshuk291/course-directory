module.exports=[43982,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_categories_route_actions_9c21f11d.js.map