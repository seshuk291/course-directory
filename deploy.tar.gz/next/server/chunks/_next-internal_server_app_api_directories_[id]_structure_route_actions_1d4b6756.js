module.exports=[16389,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directories_%5Bid%5D_structure_route_actions_1d4b6756.js.map