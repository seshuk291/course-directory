module.exports=[17692,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_videos_%5Bcourse%5D_%5Bvideo%5D_route_actions_bcdb1aef.js.map