var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/custom-names/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0f0306ec.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f4203179._.js")
R.c("server/chunks/_next-internal_server_app_api_custom-names_route_actions_3d1aeef5.js")
R.m(34887)
module.exports=R.m(34887).exports
