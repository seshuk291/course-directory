var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/chapters/[chapterId]/move/route.js")
R.c("server/chunks/[root-of-the-server]__9b353bbc._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/bec2d_app_api_directories_[id]_chapters_[chapterId]_move_route_actions_e73b9cf2.js")
R.m(38303)
module.exports=R.m(38303).exports
