var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/folders/[folderId]/reorder/route.js")
R.c("server/chunks/[root-of-the-server]__1c5d49f6._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/bec2d_app_api_directories_[id]_folders_[folderId]_reorder_route_actions_943c716f.js")
R.m(19071)
module.exports=R.m(19071).exports
