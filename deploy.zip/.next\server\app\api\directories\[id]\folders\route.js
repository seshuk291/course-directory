var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/folders/route.js")
R.c("server/chunks/[root-of-the-server]__fbe58280._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_directories_[id]_folders_route_actions_9637a2a4.js")
R.m(38324)
module.exports=R.m(38324).exports
