var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__9dc4f47e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_directories_[id]_route_actions_05e5250c.js")
R.m(66080)
module.exports=R.m(66080).exports
