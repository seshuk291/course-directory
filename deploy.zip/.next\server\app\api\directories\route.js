var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/directories/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f4e0240f.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f4203179._.js")
R.c("server/chunks/_next-internal_server_app_api_directories_route_actions_63829104.js")
R.m(54815)
module.exports=R.m(54815).exports
