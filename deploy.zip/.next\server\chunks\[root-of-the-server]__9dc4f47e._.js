module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},88917,(e,t,r)=>{t.exports=e.x("sqlite3",()=>require("sqlite3"))},84168,e=>{"use strict";var t=e.i(88917),r=e.i(14747);let a=r.default.join(process.cwd(),"course-directories.db");async function i(){return new Promise((e,r)=>{let i=new t.default.Database(a,t=>{t?r(t):(console.log("Running database migrations..."),i.serialize(()=>{i.run(`
          CREATE TABLE IF NOT EXISTS migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),i.get("SELECT name FROM migrations WHERE name = 'add_category_support'",(t,a)=>{var n,E,s,d,l,T;t?r(t):a?(console.log("Migration already applied: add_category_support"),n=i,E=()=>{o(i,e,r)},s=r,n.get("SELECT name FROM sqlite_master WHERE type='table' AND name='chapters'",(e,t)=>{e?s(e):t?(console.log("Chapters table already exists"),E()):(console.log("Creating missing chapters table..."),n.run(`
          CREATE TABLE IF NOT EXISTS chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            folder_id INTEGER,
            name TEXT NOT NULL,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            original_path TEXT,
            type TEXT DEFAULT 'html',
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
          )
        `,e=>{e?(console.error("Error creating chapters table:",e),s(e)):(console.log("Chapters table created successfully"),E())}))})):(console.log("Running migration: add_category_support"),d=i,l=()=>{o(i,e,r)},T=r,d.run(`
    CREATE TABLE IF NOT EXISTS selected_directories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      original_path TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),d.run(`
    CREATE TABLE IF NOT EXISTS course_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      color TEXT DEFAULT '#3b82f6',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),d.all("PRAGMA table_info(selected_directories)",(e,t)=>{e?T(e):(t.some(e=>"category_id"===e.name)||d.run(`
          ALTER TABLE selected_directories 
          ADD COLUMN category_id INTEGER REFERENCES course_categories(id)
        `),d.run(`
        CREATE TABLE IF NOT EXISTS folder_hierarchy (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          parent_id INTEGER,
          folder_name TEXT NOT NULL,
          display_name TEXT,
          folder_path TEXT NOT NULL,
          level INTEGER DEFAULT 0,
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
        )
      `),d.run(`
        CREATE TABLE IF NOT EXISTS chapters (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          folder_id INTEGER,
          name TEXT NOT NULL,
          filename TEXT NOT NULL,
          path TEXT NOT NULL,
          original_path TEXT,
          type TEXT DEFAULT 'html',
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
        )
      `),d.run("INSERT INTO migrations (name) VALUES ('add_category_support')",e=>{e?T(e):(console.log("Migration completed: add_category_support"),l())}))}))})}))})})}function o(e,t,r){e.get("SELECT name FROM migrations WHERE name = 'add_progress_tracking'",(a,i)=>{a?r(a):i?(console.log("Migration already applied: add_progress_tracking"),e.close(e=>{e?r(e):t()})):(console.log("Running migration: add_progress_tracking"),e.run(`
          CREATE TABLE IF NOT EXISTS chapter_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            chapter_path TEXT NOT NULL,
            completed BOOLEAN DEFAULT FALSE,
            completed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            UNIQUE(directory_id, chapter_path)
          )
        `,a=>{if(a){console.error("Error creating chapter_progress table:",a),r(a);return}e.run("INSERT INTO migrations (name) VALUES ('add_progress_tracking')",a=>{a?r(a):(console.log("Migration completed: add_progress_tracking"),e.close(e=>{e?r(e):t()}))})}))})}let n=r.default.join(process.cwd(),"course-directories.db");function E(){return new Promise(async(e,r)=>{try{await i()}catch(e){console.error("Migration failed:",e)}let a=new t.default.Database(n,t=>{t?r(t):a.serialize(()=>{a.run(`
          CREATE TABLE IF NOT EXISTS course_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            color TEXT DEFAULT '#3b82f6',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS selected_directories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            category_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES course_categories (id) ON DELETE SET NULL
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS custom_names (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            file_path TEXT NOT NULL,
            original_name TEXT NOT NULL,
            custom_name TEXT NOT NULL,
            is_directory BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS folder_hierarchy (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            parent_id INTEGER,
            folder_name TEXT NOT NULL,
            display_name TEXT,
            folder_path TEXT NOT NULL,
            level INTEGER DEFAULT 0,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
          )
        `),e(a)})})})}class s{db=null;async init(){this.db=await E()}async addDirectory(e,t,r){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT OR REPLACE INTO selected_directories (original_path, display_name, category_id, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      `);o.run([e,t,r||null],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getSelectedDirectories(){return new Promise((e,t)=>{this.db?this.db.all("SELECT * FROM selected_directories ORDER BY display_name",(r,a)=>{r?t(r):e(a)}):t(Error("Database not initialized"))})}async removeDirectory(e){return new Promise((t,r)=>{this.db?this.db.run("DELETE FROM selected_directories WHERE id = ?",[e],e=>{e?r(e):t()}):r(Error("Database not initialized"))})}async updateDirectory(e,t,r){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        UPDATE selected_directories 
        SET display_name = ?, category_id = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);o.run([t,r||null,e],e=>{e?i(e):a()}),o.finalize()})}async setCustomName(e,t,r,a,i=!1){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let E=this.db.prepare(`
        INSERT OR REPLACE INTO custom_names 
        (directory_id, file_path, original_name, custom_name, is_directory, updated_at) 
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `);E.run([e,t,r,a,i],e=>{e?n(e):o()}),E.finalize()})}async getCustomNames(e){return new Promise((t,r)=>{this.db?this.db.all("SELECT * FROM custom_names WHERE directory_id = ?",[e],(e,a)=>{e?r(e):t(a)}):r(Error("Database not initialized"))})}async close(){return new Promise((e,t)=>{this.db?this.db.close(r=>{r?t(r):e()}):e()})}async createCategory(e,t,r="#3b82f6"){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT INTO course_categories (name, description, color) 
        VALUES (?, ?, ?)
      `);o.run([e,t||null,r],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getCategories(){return new Promise((e,t)=>{this.db?this.db.all("SELECT * FROM course_categories ORDER BY name",(r,a)=>{r?t(r):e(a)}):t(Error("Database not initialized"))})}async updateCategory(e,t,r,a){return new Promise((i,o)=>{if(!this.db)return void o(Error("Database not initialized"));let n=this.db.prepare(`
        UPDATE course_categories 
        SET name = ?, description = ?, color = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);n.run([t,r||null,a||"#3b82f6",e],e=>{e?o(e):i()}),n.finalize()})}async deleteCategory(e){return new Promise((t,r)=>{this.db?this.db.run("DELETE FROM course_categories WHERE id = ?",[e],e=>{e?r(e):t()}):r(Error("Database not initialized"))})}async createFolderHierarchy(e,t,r,a,i){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let E=0;if(a)this.db.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(s,d)=>{if(s)return void n(s);d&&(E=d.level+1);let l=this.db.prepare(`
              INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
              VALUES (?, ?, ?, ?, ?, ?)
            `);l.run([e,a||null,t,i||null,r,E],function(e){e?n(e):o(this.lastID)}),l.finalize()});else{let a=this.db.prepare(`
          INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
          VALUES (?, ?, ?, ?, ?, ?)
        `);a.run([e,null,t,i||null,r,E],function(e){e?n(e):o(this.lastID)}),a.finalize()}})}async getFolderHierarchy(e){return new Promise((t,r)=>{this.db?this.db.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,a)=>{e?r(e):t(a)}):r(Error("Database not initialized"))})}async getDirectoriesWithCategories(){return new Promise((e,t)=>{if(!this.db)return void t(Error("Database not initialized"));let r=`
        SELECT d.*, c.name as category_name, c.description as category_description, c.color as category_color
        FROM selected_directories d
        LEFT JOIN course_categories c ON d.category_id = c.id
        ORDER BY c.name, d.display_name
      `;this.db.all(r,(r,a)=>{r?t(r):e(a.map(e=>({id:e.id,original_path:e.original_path,display_name:e.display_name,category_id:e.category_id,created_at:e.created_at,updated_at:e.updated_at,category:e.category_name?{id:e.category_id,name:e.category_name,description:e.category_description,color:e.category_color,created_at:"",updated_at:""}:void 0})))})})}async markChapterCompleted(e,t){return new Promise((r,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `);i.run([e,t,!0],e=>{e?a(e):r()}),i.finalize()})}async markChapterIncomplete(e,t){return new Promise((r,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, NULL, CURRENT_TIMESTAMP)
      `);i.run([e,t,!1],e=>{e?a(e):r()}),i.finalize()})}async getChapterProgress(e){return new Promise((t,r)=>{this.db?this.db.all("SELECT * FROM chapter_progress WHERE directory_id = ?",[e],(e,a)=>{e?r(e):t(a)}):r(Error("Database not initialized"))})}async getCourseProgress(e){return new Promise((t,r)=>{this.db?this.db.get("SELECT COUNT(*) as total FROM chapters WHERE directory_id = ?",[e],(a,i)=>{if(a)return void r(a);let o=i?.total||0;this.db?this.db.get("SELECT COUNT(*) as completed FROM chapter_progress WHERE directory_id = ? AND completed = ?",[e,!0],(e,a)=>{if(e)r(e);else{let e=a?.completed||0,r=o>0?Math.round(e/o*100):0;t({total:o,completed:e,percentage:r})}}):r(Error("Database not initialized"))}):r(Error("Database not initialized"))})}}async function d(e){let t=await E();return new Promise((r,a)=>{t.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,t)=>{e?a(e):r((t||[]).map(e=>({...e,name:e.folder_name,displayName:e.display_name,path:e.folder_path,parentId:e.parent_id,children:[],chapters:[],sortOrder:e.sort_order})))})})}async function l(e,t,r,a){let i=await E();return new Promise((o,n)=>{let E=0;a?i.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(s,d)=>{s?n(s):(E=(d?.level||0)+1,i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
             VALUES (?, ?, ?, ?, ?, ?)`,[e,a,t,r,t,E],function(e){e?n(e):o(this.lastID)}))}):i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
         VALUES (?, ?, ?, ?, ?, ?)`,[e,null,t,r,t,0],function(e){e?n(e):o(this.lastID)})})}e.s(["DirectoryManager",()=>s,"createFolder",()=>l,"getDirectoryFolders",()=>d,"initDatabase",()=>E],84168)},66080,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),i=e.i(59756),o=e.i(61916),n=e.i(14444),E=e.i(37092),s=e.i(69741),d=e.i(16795),l=e.i(87718),T=e.i(95169),c=e.i(47587),p=e.i(66012),u=e.i(70101),R=e.i(26937),_=e.i(10372),N=e.i(93695);e.i(52474);var A=e.i(220),h=e.i(89171),I=e.i(84168);async function m(e,t){try{let{id:r}=await t.params,{displayName:a,categoryId:i}=await e.json();if(!a?.trim())return h.NextResponse.json({error:"Display name is required"},{status:400});let o=new I.DirectoryManager;return await o.init(),await o.updateDirectory(parseInt(r),a.trim(),i),await o.close(),h.NextResponse.json({message:"Course updated successfully"})}catch(e){return console.error("Error updating course:",e),h.NextResponse.json({error:"Failed to update course"},{status:500})}}async function y(e,t){try{let{id:e}=await t.params,r=new I.DirectoryManager;return await r.init(),await r.removeDirectory(parseInt(e)),await r.close(),h.NextResponse.json({message:"Course removed successfully"})}catch(e){return console.error("Error removing course:",e),h.NextResponse.json({error:"Failed to remove course"},{status:500})}}e.s(["DELETE",()=>y,"PUT",()=>m],47336);var g=e.i(47336);let C=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/directories/[id]/route",pathname:"/api/directories/[id]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/directories/[id]/route.ts",nextConfigOutput:"standalone",userland:g}),{workAsyncStorage:L,workUnitAsyncStorage:M,serverHooks:U}=C;function D(){return(0,a.patchFetch)({workAsyncStorage:L,workUnitAsyncStorage:M})}async function S(e,t,a){C.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let h="/api/directories/[id]/route";h=h.replace(/\/index$/,"")||"/";let I=await C.prepare(e,t,{srcPage:h,multiZoneDraftMode:!1});if(!I)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:m,params:y,nextConfig:g,parsedUrl:L,isDraftMode:M,prerenderManifest:U,routerServerContext:D,isOnDemandRevalidate:S,revalidateOnlyGenerated:f,resolvedPathname:O,clientReferenceManifest:b,serverActionsManifest:F}=I,P=(0,s.normalizeAppPath)(h),v=!!(U.dynamicRoutes[P]||U.routes[O]),w=async()=>((null==D?void 0:D.render404)?await D.render404(e,t,L,!1):t.end("This page could not be found"),null);if(v&&!M){let e=!!U.routes[O],t=U.dynamicRoutes[P];if(t&&!1===t.fallback&&!e){if(g.experimental.adapterPath)return await w();throw new N.NoFallbackError}}let x=null;!v||C.isDev||M||(x="/index"===(x=O)?"/":x);let X=!0===C.isDev||!v,G=v&&!X;F&&b&&(0,n.setReferenceManifestsSingleton)({page:h,clientReferenceManifest:b,serverActionsManifest:F,serverModuleMap:(0,E.createServerModuleMap)({serverActionsManifest:F})});let Y=e.method||"GET",H=(0,o.getTracer)(),z=H.getActiveScopeSpan(),K={params:y,prerenderManifest:U,renderOpts:{experimental:{authInterrupts:!!g.experimental.authInterrupts},cacheComponents:!!g.cacheComponents,supportsDynamicResponse:X,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:g.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a)=>C.onRequestError(e,t,a,D)},sharedContext:{buildId:m}},k=new d.NodeNextRequest(e),q=new d.NodeNextResponse(t),j=l.NextRequestAdapter.fromNodeNextRequest(k,(0,l.signalFromNodeResponse)(t));try{let n=async e=>C.handle(j,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=H.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==T.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${Y} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${Y} ${h}`)}),E=!!(0,i.getRequestMeta)(e,"minimalMode"),s=async i=>{var o,s;let d=async({previousCacheEntry:r})=>{try{if(!E&&S&&f&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await n(i);e.fetchMetrics=K.renderOpts.fetchMetrics;let s=K.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let d=K.renderOpts.collectedTags;if(!v)return await (0,p.sendResponse)(k,q,o,K.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,u.toNodeOutgoingHttpHeaders)(o.headers);d&&(t[_.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=_.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=_.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await C.onRequestError(e,t,{routerKind:"App Router",routePath:h,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:S})},D),t}},l=await C.handleResponse({req:e,nextConfig:g,cacheKey:x,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:U,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:f,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:E});if(!v)return null;if((null==l||null==(o=l.value)?void 0:o.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(s=l.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});E||t.setHeader("x-nextjs-cache",S?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),M&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let T=(0,u.fromNodeOutgoingHttpHeaders)(l.value.headers);return E&&v||T.delete(_.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||T.get("Cache-Control")||T.set("Cache-Control",(0,R.getCacheControlHeader)(l.cacheControl)),await (0,p.sendResponse)(k,q,new Response(l.value.body,{headers:T,status:l.value.status||200})),null};z?await s(z):await H.withPropagatedContext(e.headers,()=>H.trace(T.BaseServerSpan.handleRequest,{spanName:`${Y} ${h}`,kind:o.SpanKind.SERVER,attributes:{"http.method":Y,"http.target":e.url}},s))}catch(t){if(t instanceof N.NoFallbackError||await C.onRequestError(e,t,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:G,isOnDemandRevalidate:S})}),v)throw t;return await (0,p.sendResponse)(k,q,new Response(null,{status:500})),null}}e.s(["handler",()=>S,"patchFetch",()=>D,"routeModule",()=>C,"serverHooks",()=>U,"workAsyncStorage",()=>L,"workUnitAsyncStorage",()=>M],66080)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__9dc4f47e._.js.map