module.exports=[93695,(e,r,t)=>{r.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},32319,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},18622,(e,r,t)=>{r.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,r,t)=>{r.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,r,t)=>{r.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},14747,(e,r,t)=>{r.exports=e.x("path",()=>require("path"))},88917,(e,r,t)=>{r.exports=e.x("sqlite3",()=>require("sqlite3"))},84168,e=>{"use strict";var r=e.i(88917),t=e.i(14747);let a=t.default.join(process.cwd(),"course-directories.db");async function i(){return new Promise((e,t)=>{let i=new r.default.Database(a,r=>{r?t(r):(console.log("Running database migrations..."),i.serialize(()=>{i.run(`
          CREATE TABLE IF NOT EXISTS migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),i.get("SELECT name FROM migrations WHERE name = 'add_category_support'",(r,a)=>{var n,E,d,s,l,c;r?t(r):a?(console.log("Migration already applied: add_category_support"),n=i,E=()=>{o(i,e,t)},d=t,n.get("SELECT name FROM sqlite_master WHERE type='table' AND name='chapters'",(e,r)=>{e?d(e):r?(console.log("Chapters table already exists"),E()):(console.log("Creating missing chapters table..."),n.run(`
          CREATE TABLE IF NOT EXISTS chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            folder_id INTEGER,
            name TEXT NOT NULL,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            original_path TEXT,
            type TEXT DEFAULT 'html',
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
          )
        `,e=>{e?(console.error("Error creating chapters table:",e),d(e)):(console.log("Chapters table created successfully"),E())}))})):(console.log("Running migration: add_category_support"),s=i,l=()=>{o(i,e,t)},c=t,s.run(`
    CREATE TABLE IF NOT EXISTS selected_directories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      original_path TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),s.run(`
    CREATE TABLE IF NOT EXISTS course_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      color TEXT DEFAULT '#3b82f6',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `),s.all("PRAGMA table_info(selected_directories)",(e,r)=>{e?c(e):(r.some(e=>"category_id"===e.name)||s.run(`
          ALTER TABLE selected_directories 
          ADD COLUMN category_id INTEGER REFERENCES course_categories(id)
        `),s.run(`
        CREATE TABLE IF NOT EXISTS folder_hierarchy (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          parent_id INTEGER,
          folder_name TEXT NOT NULL,
          display_name TEXT,
          folder_path TEXT NOT NULL,
          level INTEGER DEFAULT 0,
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
        )
      `),s.run(`
        CREATE TABLE IF NOT EXISTS chapters (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          directory_id INTEGER,
          folder_id INTEGER,
          name TEXT NOT NULL,
          filename TEXT NOT NULL,
          path TEXT NOT NULL,
          original_path TEXT,
          type TEXT DEFAULT 'html',
          sort_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
          FOREIGN KEY (folder_id) REFERENCES folder_hierarchy (id) ON DELETE SET NULL
        )
      `),s.run("INSERT INTO migrations (name) VALUES ('add_category_support')",e=>{e?c(e):(console.log("Migration completed: add_category_support"),l())}))}))})}))})})}function o(e,r,t){e.get("SELECT name FROM migrations WHERE name = 'add_progress_tracking'",(a,i)=>{a?t(a):i?(console.log("Migration already applied: add_progress_tracking"),e.close(e=>{e?t(e):r()})):(console.log("Running migration: add_progress_tracking"),e.run(`
          CREATE TABLE IF NOT EXISTS chapter_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            chapter_path TEXT NOT NULL,
            completed BOOLEAN DEFAULT FALSE,
            completed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            UNIQUE(directory_id, chapter_path)
          )
        `,a=>{if(a){console.error("Error creating chapter_progress table:",a),t(a);return}e.run("INSERT INTO migrations (name) VALUES ('add_progress_tracking')",a=>{a?t(a):(console.log("Migration completed: add_progress_tracking"),e.close(e=>{e?t(e):r()}))})}))})}let n=t.default.join(process.cwd(),"course-directories.db");function E(){return new Promise(async(e,t)=>{try{await i()}catch(e){console.error("Migration failed:",e)}let a=new r.default.Database(n,r=>{r?t(r):a.serialize(()=>{a.run(`
          CREATE TABLE IF NOT EXISTS course_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            color TEXT DEFAULT '#3b82f6',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS selected_directories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            category_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES course_categories (id) ON DELETE SET NULL
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS custom_names (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            file_path TEXT NOT NULL,
            original_name TEXT NOT NULL,
            custom_name TEXT NOT NULL,
            is_directory BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE
          )
        `),a.run(`
          CREATE TABLE IF NOT EXISTS folder_hierarchy (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id INTEGER,
            parent_id INTEGER,
            folder_name TEXT NOT NULL,
            display_name TEXT,
            folder_path TEXT NOT NULL,
            level INTEGER DEFAULT 0,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (directory_id) REFERENCES selected_directories (id) ON DELETE CASCADE,
            FOREIGN KEY (parent_id) REFERENCES folder_hierarchy (id) ON DELETE CASCADE
          )
        `),e(a)})})})}class d{db=null;async init(){this.db=await E()}async addDirectory(e,r,t){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT OR REPLACE INTO selected_directories (original_path, display_name, category_id, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      `);o.run([e,r,t||null],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getSelectedDirectories(){return new Promise((e,r)=>{this.db?this.db.all("SELECT * FROM selected_directories ORDER BY display_name",(t,a)=>{t?r(t):e(a)}):r(Error("Database not initialized"))})}async removeDirectory(e){return new Promise((r,t)=>{this.db?this.db.run("DELETE FROM selected_directories WHERE id = ?",[e],e=>{e?t(e):r()}):t(Error("Database not initialized"))})}async updateDirectory(e,r,t){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        UPDATE selected_directories 
        SET display_name = ?, category_id = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);o.run([r,t||null,e],e=>{e?i(e):a()}),o.finalize()})}async setCustomName(e,r,t,a,i=!1){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let E=this.db.prepare(`
        INSERT OR REPLACE INTO custom_names 
        (directory_id, file_path, original_name, custom_name, is_directory, updated_at) 
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `);E.run([e,r,t,a,i],e=>{e?n(e):o()}),E.finalize()})}async getCustomNames(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM custom_names WHERE directory_id = ?",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async close(){return new Promise((e,r)=>{this.db?this.db.close(t=>{t?r(t):e()}):e()})}async createCategory(e,r,t="#3b82f6"){return new Promise((a,i)=>{if(!this.db)return void i(Error("Database not initialized"));let o=this.db.prepare(`
        INSERT INTO course_categories (name, description, color) 
        VALUES (?, ?, ?)
      `);o.run([e,r||null,t],function(e){e?i(e):a(this.lastID)}),o.finalize()})}async getCategories(){return new Promise((e,r)=>{this.db?this.db.all("SELECT * FROM course_categories ORDER BY name",(t,a)=>{t?r(t):e(a)}):r(Error("Database not initialized"))})}async updateCategory(e,r,t,a){return new Promise((i,o)=>{if(!this.db)return void o(Error("Database not initialized"));let n=this.db.prepare(`
        UPDATE course_categories 
        SET name = ?, description = ?, color = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);n.run([r,t||null,a||"#3b82f6",e],e=>{e?o(e):i()}),n.finalize()})}async deleteCategory(e){return new Promise((r,t)=>{this.db?this.db.run("DELETE FROM course_categories WHERE id = ?",[e],e=>{e?t(e):r()}):t(Error("Database not initialized"))})}async createFolderHierarchy(e,r,t,a,i){return new Promise((o,n)=>{if(!this.db)return void n(Error("Database not initialized"));let E=0;if(a)this.db.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(d,s)=>{if(d)return void n(d);s&&(E=s.level+1);let l=this.db.prepare(`
              INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
              VALUES (?, ?, ?, ?, ?, ?)
            `);l.run([e,a||null,r,i||null,t,E],function(e){e?n(e):o(this.lastID)}),l.finalize()});else{let a=this.db.prepare(`
          INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
          VALUES (?, ?, ?, ?, ?, ?)
        `);a.run([e,null,r,i||null,t,E],function(e){e?n(e):o(this.lastID)}),a.finalize()}})}async getFolderHierarchy(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async getDirectoriesWithCategories(){return new Promise((e,r)=>{if(!this.db)return void r(Error("Database not initialized"));let t=`
        SELECT d.*, c.name as category_name, c.description as category_description, c.color as category_color
        FROM selected_directories d
        LEFT JOIN course_categories c ON d.category_id = c.id
        ORDER BY c.name, d.display_name
      `;this.db.all(t,(t,a)=>{t?r(t):e(a.map(e=>({id:e.id,original_path:e.original_path,display_name:e.display_name,category_id:e.category_id,created_at:e.created_at,updated_at:e.updated_at,category:e.category_name?{id:e.category_id,name:e.category_name,description:e.category_description,color:e.category_color,created_at:"",updated_at:""}:void 0})))})})}async markChapterCompleted(e,r){return new Promise((t,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `);i.run([e,r,!0],e=>{e?a(e):t()}),i.finalize()})}async markChapterIncomplete(e,r){return new Promise((t,a)=>{if(!this.db)return void a(Error("Database not initialized"));let i=this.db.prepare(`
        INSERT OR REPLACE INTO chapter_progress (directory_id, chapter_path, completed, completed_at, updated_at) 
        VALUES (?, ?, ?, NULL, CURRENT_TIMESTAMP)
      `);i.run([e,r,!1],e=>{e?a(e):t()}),i.finalize()})}async getChapterProgress(e){return new Promise((r,t)=>{this.db?this.db.all("SELECT * FROM chapter_progress WHERE directory_id = ?",[e],(e,a)=>{e?t(e):r(a)}):t(Error("Database not initialized"))})}async getCourseProgress(e){return new Promise((r,t)=>{this.db?this.db.get("SELECT COUNT(*) as total FROM chapters WHERE directory_id = ?",[e],(a,i)=>{if(a)return void t(a);let o=i?.total||0;this.db?this.db.get("SELECT COUNT(*) as completed FROM chapter_progress WHERE directory_id = ? AND completed = ?",[e,!0],(e,a)=>{if(e)t(e);else{let e=a?.completed||0,t=o>0?Math.round(e/o*100):0;r({total:o,completed:e,percentage:t})}}):t(Error("Database not initialized"))}):t(Error("Database not initialized"))})}}async function s(e){let r=await E();return new Promise((t,a)=>{r.all("SELECT * FROM folder_hierarchy WHERE directory_id = ? ORDER BY level, sort_order, folder_name",[e],(e,r)=>{e?a(e):t((r||[]).map(e=>({...e,name:e.folder_name,displayName:e.display_name,path:e.folder_path,parentId:e.parent_id,children:[],chapters:[],sortOrder:e.sort_order})))})})}async function l(e,r,t,a){let i=await E();return new Promise((o,n)=>{let E=0;a?i.get("SELECT level FROM folder_hierarchy WHERE id = ?",[a],(d,s)=>{d?n(d):(E=(s?.level||0)+1,i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
             VALUES (?, ?, ?, ?, ?, ?)`,[e,a,r,t,r,E],function(e){e?n(e):o(this.lastID)}))}):i.run(`INSERT INTO folder_hierarchy (directory_id, parent_id, folder_name, display_name, folder_path, level) 
         VALUES (?, ?, ?, ?, ?, ?)`,[e,null,r,t,r,0],function(e){e?n(e):o(this.lastID)})})}e.s(["DirectoryManager",()=>d,"createFolder",()=>l,"getDirectoryFolders",()=>s,"initDatabase",()=>E],84168)},22734,(e,r,t)=>{r.exports=e.x("fs",()=>require("fs"))},7508,e=>{"use strict";var r=e.i(22734),t=e.i(14747),a=e.i(84168);let i=new a.DirectoryManager,o=!1;async function n(){o||(await i.init(),o=!0)}function E(e,r){let a=t.default.basename(e),i=t.default.basename(r),o=a.match(/^(\d+)/),n=i.match(/^(\d+)/);if(o&&n){let e=parseInt(o[1],10),r=parseInt(n[1],10);return e!==r?e-r:a.localeCompare(i)}return o&&!n?-1:!o&&n?1:a.localeCompare(i)}function d(e){return[".mp4",".webm",".avi",".mov",".wmv",".flv",".mkv",".m4v",".3gp",".ogv"].includes(t.default.extname(e).toLowerCase())}async function s(){await n();let e=[],o=[];try{let e=await i.getCategories();o.push(...e)}catch(e){console.error("Error fetching categories:",e)}let E=t.default.join(process.cwd(),"courses");if(r.default.existsSync(E)){for(let a of r.default.readdirSync(E,{withFileTypes:!0}))if(a.isDirectory()){let r=t.default.join(E,a.name),{chapters:i,folders:o}=l(r);e.push({name:a.name,path:r,chapters:i,folders:o,originalPath:r})}}try{for(let t of(await i.getDirectoriesWithCategories()))if(r.default.existsSync(t.original_path)){let r=await (0,a.getDirectoryFolders)(t.id),o=await (0,a.initDatabase)(),n=await new Promise((e,r)=>{o.all("SELECT * FROM chapters WHERE directory_id = ? ORDER BY sort_order, name",[t.id],(t,a)=>{t?r(t):e(a||[])})});o.close();let E=n;if(0===E.length){let{chapters:e}=l(t.original_path,t.id);E=e}let d=new Map;r.forEach(e=>{d.set(e.id,{id:e.id,name:e.name||e.folder_name,displayName:e.displayName||e.display_name,path:e.path||e.folder_path,level:e.level||0,parentId:e.parentId||e.parent_id,children:[],chapters:[],sortOrder:e.sortOrder||e.sort_order||0})});let s=[];d.forEach(e=>{if(e.parentId){let r=d.get(e.parentId);r&&r.children.push(e)}else s.push(e)}),E.forEach(e=>{let r={...e,name:e.name,filename:e.filename,path:e.path,type:e.type||"html",folderId:e.folder_id||e.folderId};if(r.folderId){let e=d.get(r.folderId);e&&e.chapters.push(r)}});let _=await i.getCustomNames(t.id),u=await i.getCourseProgress(t.id),R=await i.getChapterProgress(t.id),h=new Map;R.forEach(e=>{h.set(e.chapter_path,e.completed)});let N=E.filter(e=>!e.folderId&&!e.folder_id).map(e=>({...e,completed:h.get(e.path)||!1})),m=await T(s,h);e.push({name:t.display_name,path:t.original_path,chapters:await p(N,_),folders:await c(m,_),originalPath:t.original_path,directoryId:t.id,categoryId:t.category_id,category:t.category,progress:u})}}catch(e){console.error("Error fetching selected directories:",e)}return{courses:e,categories:o}}function l(e,a){let i=[],o=new Map;!function e(a,n="",E=0){try{for(let s of r.default.readdirSync(a,{withFileTypes:!0})){let r=t.default.join(a,s.name),l=t.default.join(n,s.name);if(s.isDirectory()){let t={id:Math.random(),name:s.name,displayName:_(s.name),path:l.replace(/\\/g,"/"),level:E,children:[],chapters:[],sortOrder:0};o.set(l,t),e(r,l,E+1)}else if(s.name.endsWith(".html")||d(s.name)){let e={name:_(l),path:r,filename:l.replace(/\\/g,"/"),originalPath:r,type:function(e){if(e.endsWith(".html"));else if(d(e))return"video";return"html"}(s.name)};if(n){let r=o.get(n);r&&r.chapters.push(e)}else i.push(e)}}}catch(e){console.error(`Error reading directory ${a}:`,e)}}(e);let n=Array.from(o.values()),s=[];return i.sort((e,r)=>E(e.filename,r.filename)),n.forEach(e=>{e.chapters.sort((e,r)=>E(e.filename,r.filename))}),n.forEach(e=>{let r=e.path.split("/");if(1===r.length)s.push(e);else{let t=r.slice(0,-1).join("/"),a=o.get(t);a&&(a.children.push(e),e.parentId=a.id)}}),{chapters:i,folders:s}}async function c(e,r){let t=new Map;return r.forEach(e=>{e.is_directory&&t.set(e.file_path,e.custom_name)}),function e(r){return r.map(r=>({...r,displayName:t.get(r.path)||r.displayName,children:e(r.children),chapters:r.chapters.map(e=>({...e,name:t.get(e.filename)||e.name}))}))}(e)}async function T(e,r){return function e(t){return t.map(t=>({...t,children:e(t.children),chapters:t.chapters.map(e=>({...e,completed:r.get(e.path)||!1}))}))}(e)}async function p(e,r){let t=new Map;return r.forEach(e=>{t.set(e.file_path,e.custom_name)}),e.map(e=>({...e,name:t.get(e.filename)||e.name}))}function _(e){return t.default.parse(e).name.replace(/[-_]/g," ").replace(/\b\w/g,e=>e.toUpperCase())}function u(e,a){try{let i=t.default.join(process.cwd(),"courses",e,a.replace(/\//g,t.default.sep));if(r.default.existsSync(i))return r.default.readFileSync(i,"utf-8");return null}catch(e){return console.error("Error reading chapter content:",e),null}}async function R(e,a){try{await n();let o=(await i.getSelectedDirectories()).find(r=>r.id===e);if(!o)return null;let E=a.replace(/\//g,t.default.sep),d=t.default.join(o.original_path,E);if(r.default.existsSync(d))return r.default.readFileSync(d,"utf-8");return null}catch(e){return console.error("Error reading chapter content from selected directory:",e),null}}async function h(e,r,t){return await n(),i.addDirectory(e,r,t)}async function N(e){return await n(),i.removeDirectory(e)}async function m(e,r,t,a,o=!1){return await n(),i.setCustomName(e,r,t,a,o)}async function f(e,r,t){return await n(),i.createCategory(e,r,t)}async function y(){return await n(),i.getCategories()}async function I(e,r,t,a){return await n(),i.updateCategory(e,r,t,a)}async function g(e){return await n(),i.deleteCategory(e)}e.s(["addSelectedDirectory",()=>h,"createCategory",()=>f,"deleteCategory",()=>g,"getCategories",()=>y,"getChapterContent",()=>u,"getChapterContentFromSelectedDir",()=>R,"getCourseStructure",()=>s,"removeSelectedDirectory",()=>N,"setCustomFileName",()=>m,"updateCategory",()=>I])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__f4203179._.js.map