module.exports=[63968,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_categories_%5Bid%5D_route_actions_521bfe4c.js.map