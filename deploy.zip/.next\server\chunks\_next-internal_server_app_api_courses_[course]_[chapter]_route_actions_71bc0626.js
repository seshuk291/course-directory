module.exports=[30784,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_courses_%5Bcourse%5D_%5Bchapter%5D_route_actions_71bc0626.js.map