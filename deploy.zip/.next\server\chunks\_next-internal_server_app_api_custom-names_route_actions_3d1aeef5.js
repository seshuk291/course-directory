module.exports=[32662,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_custom-names_route_actions_3d1aeef5.js.map