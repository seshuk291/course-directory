module.exports=[37874,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directories_%5Bid%5D_folders_route_actions_9637a2a4.js.map