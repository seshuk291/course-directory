module.exports=[10217,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directories_route_actions_63829104.js.map